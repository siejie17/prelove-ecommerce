<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="footer.css">
</head>
<body>
    <div class="footer-container">
        <section id="copy-right">
            <div class="copy-right-sec"><i class="fa-solid fa-copyright"></i>  
                Copyright &copy; <?php echo date('Y')?> <a href="index.php">Prelovebyjosie.</a>  All Rights Reserved. Powered By CodeCrafters team.
            </div>
        </section>
    </div>

</body>
</html>
